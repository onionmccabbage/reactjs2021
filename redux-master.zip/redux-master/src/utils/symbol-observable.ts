const $$observable = /* #__PURE__ */ (() =>
  (typeof Symbol === 'function' && (Symbol as any).observable) ||
  '@@observable')()

export default $$observable
